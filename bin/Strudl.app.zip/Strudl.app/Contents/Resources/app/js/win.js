
/*
000   000  000  000   000
000 0 000  000  0000  000
000000000  000  000 0 000
000   000  000  000  0000
00     00  000  000   000
 */
var Data, Proxy, View, _, app, data, debugMenu, fs, ipc, keyname, loadFile, log, path, prxy, remote, toggleStyle, view, win;

_ = require('lodash');

fs = require('fs');

ipc = require('ipc');

path = require('path');

remote = require('remote');

log = require('./js/coffee/tools/log');

keyname = require('./js/coffee/tools/keyname');

Data = require('./js/coffee/data');

Proxy = require('./js/coffee/proxy');

View = require('./js/coffee/view');

app = remote.require('app');

win = remote.getCurrentWindow();

debugMenu = require('debug-menu');

debugMenu.install();

data = null;

prxy = null;

view = null;

win.on('reloadFile', function() {
  log('reload file', win.filePath);
  return loadFile(win.filePath);
});

win.on('findPath', function() {
  return view.findPath();
});

win.on('findValue', function() {
  return view.findValue();
});

win.on('clearFind', function() {
  return view.find.clear();
});

loadFile = function(p) {
  var title;
  log('on loadFile', path);
  data = new Data();
  prxy = new Proxy(data);
  view = new View(prxy, document.getElementById('tree'));
  log("\nloading data from file " + p);
  data.load(p);
  win.setRepresentedFilename(p);
  app.addRecentDocument(p);
  title = path.basename(p);
  return win.setTitle(title);
};


/*
000       0000000    0000000   0000000    00000000  0000000  
000      000   000  000   000  000   000  000       000   000
000      000   000  000000000  000   000  0000000   000   000
000      000   000  000   000  000   000  000       000   000
0000000   0000000   000   000  0000000    00000000  0000000
 */

document.addEventListener('DOMContentLoaded', function() {
  loadFile(win.filePath);
  return win.emit('domLoaded');
});


/*
00000000   00000000   0000000  000  0000000  00000000
000   000  000       000       000     000   000     
0000000    0000000   0000000   000    000    0000000 
000   000  000            000  000   000     000     
000   000  00000000  0000000   000  0000000  00000000
 */

win.on('resize', function() {
  return view.update();
});


/*
000   000  00000000  000   000  0000000     0000000   000   000  000   000
000  000   000        000 000   000   000  000   000  000 0 000  0000  000
0000000    0000000     00000    000   000  000   000  000000000  000 0 000
000  000   000          000     000   000  000   000  000   000  000  0000
000   000  00000000     000     0000000     0000000   00     00  000   000
 */

document.addEventListener('keydown', function(event) {
  var e, key;
  key = keyname.ofEvent(event);
  e = document.activeElement;
  switch (key) {
    case 'command+i':
      return toggleStyle();
    case 'command+w':
      return win.close();
  }
});


/*
 0000000  000000000  000   000  000      00000000
000          000      000 000   000      000     
0000000      000       00000    000      0000000 
     000     000        000     000      000     
0000000      000        000     0000000  00000000
 */

toggleStyle = function() {
  var currentScheme, link, newlink, nextSchemeIndex, schemes;
  link = document.getElementById('style-link');
  log(link, link.href, new String(link.href).split('/'));
  currentScheme = _.last(new String(link.href).split('/'));
  schemes = ['dark.css', 'bright.css'];
  nextSchemeIndex = (schemes.indexOf(currentScheme) + 1) % schemes.length;
  newlink = document.createElement('link');
  newlink.rel = 'stylesheet';
  newlink.type = 'text/css';
  newlink.href = 'style/' + schemes[nextSchemeIndex];
  newlink.id = 'style-link';
  return link.parentNode.replaceChild(newlink, link);
};

//# sourceMappingURL=win.js.map

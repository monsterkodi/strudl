
/*
 0000000   00000000   00000000 
000   000  000   000  000   000
000000000  00000000   00000000 
000   000  000        000      
000   000  000        000
 */
var debugel, main, prefs;

debugel = require('electron-debug');

prefs = require('./coffee/tools/prefs');

main = require('./coffee/main');

debugel({
  showDevTools: false
});

prefs.debug = false;

prefs.init("/Users/kodi/Projects/strudl/prefs.json", {
  open: [],
  recent: [],
  windows: []
});

main.init();

//# sourceMappingURL=app.js.map

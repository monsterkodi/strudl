
/*
 0000000  000  0000000  00000000  00000000 
000       000     000   000       000   000
0000000   000    000    0000000   0000000  
     000  000   000     000       000   000
0000000   000  0000000  00000000  000   000
 */
var Drag, Sizer,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Drag = require('./drag');

Sizer = (function(superClass) {
  extend(Sizer, superClass);

  function Sizer(view) {
    this.view = view;
    this.onDrag = bind(this.onDrag, this);
    Sizer.__super__.constructor.call(this, this.view.tree.nextElementSibling.getElementsByClassName('sizer')[0]);
    this.elem.style.left = (this.view.col('val').offsetLeft - this.elem.offsetWidth) + "px";
  }

  Sizer.prototype.onDrag = function(event) {
    var dx;
    dx = event.clientX - this.elem.offsetWidth - this.x;
    if (dx) {
      if (this.view.onResizeColumn(this.x, dx)) {
        if (event.clientX) {
          this.elem.style.left = event.clientX + "px";
        }
      }
      return Sizer.__super__.onDrag.apply(this, arguments);
    }
  };

  return Sizer;

})(Drag);

module.exports = Sizer;

//# sourceMappingURL=sizer.js.map

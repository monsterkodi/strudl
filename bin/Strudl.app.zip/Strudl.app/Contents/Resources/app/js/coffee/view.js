
/*
000   000  000  00000000  000   000
000   000  000  000       000 0 000
 000 000   000  0000000   000000000
   000     000  000       000   000
    0      000  00000000  00     00
 */
var Drag, Find, Item, Model, Path, Proxy, Sizer, View, ViewItem, _, keyname, log, profile,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

_ = require('lodash');

log = require('./tools/log');

Model = require('./model');

Proxy = require('./proxy');

Item = require('./item');

Path = require('./path');

Find = require('./find');

Drag = require('./drag');

Sizer = require('./sizer');

profile = require('./tools/profile');

ViewItem = require('./viewitem');

keyname = require('./tools/keyname');

View = (function(superClass) {
  extend(View, superClass);

  function View(base, tree) {
    var tmp, tp;
    this.tree = tree;
    this.onKeyDown = bind(this.onKeyDown, this);
    this.refocus = bind(this.refocus, this);
    this.onDidInsert = bind(this.onDidInsert, this);
    this.onWillRemove = bind(this.onWillRemove, this);
    this.onDidLayout = bind(this.onDidLayout, this);
    this.focusSelected = bind(this.focusSelected, this);
    this.onKeyPath = bind(this.onKeyPath, this);
    this.onDrag = bind(this.onDrag, this);
    this.onScrollDrag = bind(this.onScrollDrag, this);
    this.onWheel = bind(this.onWheel, this);
    this.onDidReload = bind(this.onDidReload, this);
    this.onWillReload = bind(this.onWillReload, this);
    View.__super__.constructor.call(this, base, 'view', this.tree);
    this.tree.addEventListener('keydown', this.onKeyDown);
    this.tree.addEventListener('wheel', this.onWheel);
    this.tree.tabIndex = -1;
    this.topIndex = 0;
    this.botIndex = 0;
    this.selIndex = -1;
    this.scroll = 0;
    tp = this.tree.parentElement;
    this.scrollLeft = this.getElem('scroll left', tp);
    this.leftDrag = new Drag(this.getElem('scrollbar left', tp));
    this.leftDrag.on('drag', this.onScrollDrag);
    this.scrollRight = this.getElem('scroll right', tp);
    this.rightDrag = new Drag(this.getElem('scrollbar right', tp));
    this.rightDrag.on('drag', this.onScrollDrag);
    this.keyPath = new Path(document.getElementById('path'));
    this.keyPath.on('keypath', this.onKeyPath);
    this.find = new Find(this, document.getElementById('find'));
    this.find.on('blur', this.refocus);
    this.find.on('hidden', this.refocus);
    this.find.elem.style.display = 'none';
    tmp = document.createElement('div');
    tmp.className = 'tree-item';
    this.tree.appendChild(tmp);
    this.lineHeight = tmp.offsetHeight;
    tmp.remove();
  }

  View.prototype.setBase = function(base) {
    View.__super__.setBase.call(this, base);
    return this.base.on("didLayout", this.onDidLayout);
  };


  /*
  00000000   00000000  000       0000000    0000000   0000000  
  000   000  000       000      000   000  000   000  000   000
  0000000    0000000   000      000   000  000000000  000   000
  000   000  000       000      000   000  000   000  000   000
  000   000  00000000  0000000   0000000   000   000  0000000
   */

  View.prototype.onWillReload = function() {
    return this.root = null;
  };

  View.prototype.onDidReload = function() {
    if (this.base != null) {
      this.root = this.createItem(-1, this.base.root, this);
      return this.root.elem = this.tree;
    }
  };

  View.prototype.viewHeight = function() {
    return document.getElementById('container').offsetHeight - document.getElementById('path').offsetHeight - document.getElementById('find').offsetHeight;
  };

  View.prototype.numViewLines = function() {
    return Math.ceil(this.viewHeight() / this.lineHeight);
  };

  View.prototype.numFullLines = function() {
    return Math.floor(this.viewHeight() / this.lineHeight);
  };

  View.prototype.numVisibleLines = function() {
    var ref;
    return ((ref = this.base.root) != null ? ref.numVisible : void 0) || 0;
  };


  /*
   0000000   0000000  00000000    0000000   000      000    
  000       000       000   000  000   000  000      000    
  0000000   000       0000000    000   000  000      000    
       000  000       000   000  000   000  000      000    
  0000000    0000000  000   000   0000000   0000000  0000000
   */

  View.prototype.scrollLines = function(lineDelta) {
    return this.scrollBy(lineDelta * this.lineHeight);
  };

  View.prototype.scrollFactor = function(event) {
    var f;
    f = 1;
    f *= 1 + 9 * event.metaKey;
    f *= 1 + 99 * event.altKey;
    return f *= 1 + 999 * event.ctrlKey;
  };

  View.prototype.onWheel = function(event) {
    return this.scrollBy(event.deltaY * this.scrollFactor(event));
  };

  View.prototype.onScrollDrag = function(drag) {
    var delta;
    delta = -(drag.dy / this.linesHeight) * this.treeHeight;
    return this.scrollBy(delta);
  };

  View.prototype.onDrag = function(drag) {
    return this.scrollBy(drag.dy);
  };

  View.prototype.scrollBy = function(delta) {
    var bot, numLines, top, viewLines;
    numLines = this.numVisibleLines();
    viewLines = this.numViewLines();
    this.treeHeight = numLines * this.lineHeight;
    this.linesHeight = viewLines * this.lineHeight;
    this.scrollMax = this.treeHeight - this.linesHeight + this.lineHeight;
    this.scroll += delta;
    this.scroll = Math.min(this.scroll, this.scrollMax);
    this.scroll = Math.max(this.scroll, 0);
    top = parseInt(this.scroll / this.lineHeight);
    bot = Math.min(this.topIndex + viewLines - 1, numLines - 1);
    if (this.topIndex !== top || this.botIndex !== bot) {
      if (this.selIndex < top) {
        return this.selectIndex(top);
      } else if (this.selIndex >= top + this.numFullLines()) {
        return this.selectIndex(top + this.numFullLines() - 1);
      } else {
        return this.update();
      }
    }
  };


  /*
   0000000  00000000  000      00000000   0000000  000000000
  000       000       000      000       000          000   
  0000000   0000000   000      0000000   000          000   
       000  000       000      000       000          000   
  0000000   00000000  0000000  00000000   0000000     000
   */

  View.prototype.selectedItem = function() {
    return this.closestItemForVisibleIndex(this.selIndex);
  };

  View.prototype.selectIndex = function(index) {
    var ref;
    this.selIndex = index;
    this.selIndex = Math.max(0, Math.min(this.selIndex, this.numVisibleLines() - 1));
    this.keyPath.set((ref = this.base.visibleItems[this.selIndex]) != null ? ref.dataItem().keyPath() : void 0);
    return this.update();
  };

  View.prototype.selectDelta = function(lineDelta) {
    return this.selectIndex(this.selIndex + lineDelta);
  };

  View.prototype.selectUp = function(event) {
    return this.selectDelta(-this.scrollFactor(event));
  };

  View.prototype.selectDown = function(event) {
    return this.selectDelta(this.scrollFactor(event));
  };

  View.prototype.onKeyPath = function(keypath) {
    return this.selectIndex(this.base.itemAt(keypath).visibleIndex);
  };

  View.prototype.focusSelected = function() {
    if (!document.activeElement.classList.contains('tree-item')) {
      return this.selectedItem().focus();
    }
  };


  /*
  000   000  00000000   0000000     0000000   000000000  00000000
  000   000  000   000  000   000  000   000     000     000     
  000   000  00000000   000   000  000000000     000     0000000 
  000   000  000        000   000  000   000     000     000     
   0000000   000        0000000    000   000     000     00000000
   */

  View.prototype.update = function() {
    var baseItem, child, doProfile, i, item, j, k, keypath, len, numLines, ref, ref1, ref2, selItem, setFocus, viewLines;
    doProfile = false;
    numLines = this.numVisibleLines();
    viewLines = this.numViewLines();
    if (doProfile) {
      profile("update " + numLines);
    }
    setFocus = document.activeElement.classList.contains('tree-item');
    this.treeHeight = numLines * this.lineHeight;
    this.linesHeight = viewLines * this.lineHeight;
    this.topIndex = parseInt(this.scroll / this.lineHeight);
    this.botIndex = Math.min(this.topIndex + viewLines - 1, numLines - 1);
    if (this.selIndex < this.topIndex) {
      this.topIndex = this.selIndex;
      this.botIndex = Math.min(this.topIndex + viewLines - 1, numLines - 1);
      if (this.botIndex - this.topIndex < Math.min(viewLines, numLines) - 1) {
        this.topIndex = this.botIndex - Math.min(viewLines, numLines) + 1;
      }
      this.scroll = this.topIndex * this.lineHeight;
    } else if (this.selIndex >= this.topIndex + this.numFullLines()) {
      this.topIndex = this.selIndex - this.numFullLines() + 1;
      this.topIndex = Math.max(0, this.topIndex);
      this.botIndex = Math.min(this.topIndex + viewLines - 1, numLines - 1);
      this.scroll = this.topIndex * this.lineHeight;
    }
    ref = this.tree.children;
    for (j = 0, len = ref.length; j < len; j++) {
      child = ref[j];
      child.innerHTML = "";
    }
    if (numLines) {
      this.root.children = [];
      this.root.keyIndex = {};
      for (i = k = ref1 = this.topIndex, ref2 = this.botIndex; ref1 <= ref2 ? k <= ref2 : k >= ref2; i = ref1 <= ref2 ? ++k : --k) {
        baseItem = this.base.visibleItems[i];
        this.root.keyIndex[baseItem.key] = numLines;
        item = this.createItem(baseItem.key, baseItem, this.root);
        this.root.children.push(item);
        item.createElement();
      }
      this.updateSize();
      this.updateScroll();
      selItem = this.closestItemForVisibleIndex(this.selIndex);
      if (setFocus) {
        selItem.focus();
      } else {
        selItem.ownClass("selected", selItem.lin);
      }
      if (selItem.value.visibleIndex !== this.selIndex) {
        this.selIndex = selItem.value.visibleIndex;
      }
      keypath = this.base.visibleItems[this.selIndex].dataItem().keyPath();
      if (this.keyPath.key !== keypath) {
        this.keyPath.set(keypath);
      }
      this.tree.children[1].scrollLeft = selItem.elm.scrollWidth - this.tree.children[1].clientWidth;
    } else {
      this.keyPath.set([]);
      this.scroll = 0;
      this.treeHeight = this.lineHeight;
      this.updateScroll();
    }
    if (doProfile) {
      return profile("");
    }
  };

  View.prototype.updateSize = function() {
    var ic, iw, ix, kc, kw, kx, nc, nw, nx, ref, ref1, ref2, vc, vd, vw, vx;
    ref = [this.col('idx'), this.col('key'), this.col('val'), this.col('num')], ic = ref[0], kc = ref[1], vc = ref[2], nc = ref[3];
    ref1 = [ic.offsetLeft, kc.offsetLeft, vc.offsetLeft, nc.offsetLeft], ix = ref1[0], kx = ref1[1], vx = ref1[2], nx = ref1[3];
    ref2 = [ic.offsetWidth, kc.offsetWidth, vc.offsetWidth, nc.offsetWidth], iw = ref2[0], kw = ref2[1], vw = ref2[2], nw = ref2[3];
    vd = vw - this.getWidth(vc);
    return this.setWidth(vc, -vd + this.getWidth(this.tree) - nw - kw - iw);
  };

  View.prototype.updateScroll = function() {
    var scrollHeight, scrollTop, vh;
    vh = Math.min(this.linesHeight, this.viewHeight());
    scrollTop = parseInt((this.scroll / this.treeHeight) * vh);
    scrollTop = Math.max(0, scrollTop);
    scrollHeight = parseInt((this.linesHeight / this.treeHeight) * vh);
    scrollHeight = Math.max(scrollHeight, parseInt(this.lineHeight / 4));
    scrollTop = Math.min(scrollTop, this.numFullLines() * this.lineHeight - scrollHeight - 1);
    this.scrollLeft.classList.toggle('flashy', scrollHeight < this.lineHeight);
    this.scrollLeft.style.top = scrollTop + ".px";
    this.scrollLeft.style.height = scrollHeight + ".px";
    this.scrollRight.classList.toggle('flashy', scrollHeight < this.lineHeight);
    this.scrollRight.style.top = scrollTop + ".px";
    return this.scrollRight.style.height = scrollHeight + ".px";
  };


  /*
  000       0000000   000   000   0000000   000   000  000000000
  000      000   000   000 000   000   000  000   000     000   
  000      000000000    00000    000   000  000   000     000   
  000      000   000     000     000   000  000   000     000   
  0000000  000   000     000      0000000    0000000      000
   */

  View.prototype.col = function(name) {
    return this.getElem(name);
  };

  View.prototype.onResizeColumn = function(x, dx) {
    var kc, kr, kw, kx, ref, ref1, ref2, ref3, ref4, sr, sx, vc, vr, vw, vx;
    ref = [this.col('key'), this.col('val')], kc = ref[0], vc = ref[1];
    ref1 = [kc.offsetLeft, this.getWidth(kc)], kx = ref1[0], kw = ref1[1];
    ref2 = [vc.offsetLeft, this.getWidth(vc)], vx = ref2[0], vw = ref2[1];
    ref3 = [kx + kw, vx + vw], kr = ref3[0], vr = ref3[1];
    ref4 = [x - kx + dx, vw - x - dx + vx], sx = ref4[0], sr = ref4[1];
    if (sx <= 100 || sr <= 100) {
      return false;
    } else {
      this.setWidth(kc, sx);
      this.setWidth(vc, (kw + vw) - sx);
    }
    this.update();
    return true;
  };

  View.prototype.onDidLayout = function(baseItem) {
    var ref;
    if (this.selIndex < 0) {
      this.selectIndex(0);
      if ((ref = this.root.children[0]) != null) {
        ref.focus();
      }
    } else if (this.selIndex >= this.numVisibleLines()) {
      this.selectIndex(this.numVisibleLines() - 1);
    } else {
      this.update();
    }
    if (!this.sizer) {
      return this.sizer = new Sizer(this);
    }
  };


  /*
  000  000000000  00000000  00     00
  000     000     000       000   000
  000     000     0000000   000000000
  000     000     000       000 0 000
  000     000     00000000  000   000
   */

  View.prototype.newItem = function(key, value, parent) {
    return new ViewItem(key, value, parent);
  };

  View.prototype.partiallyVisible = function(item) {
    return (item.key.offsetTop + item.key.offsetHeight) > this.viewHeight();
  };

  View.prototype.closestItemForVisibleIndex = function(index) {
    var item, j, len, ref;
    if (this.root.children.length) {
      if (index <= _.first(this.root.children).value.visibleIndex) {
        return _.first(this.root.children);
      }
      if (index >= _.last(this.root.children).value.visibleIndex) {
        return _.last(this.root.children);
      }
      ref = this.root.children;
      for (j = 0, len = ref.length; j < len; j++) {
        item = ref[j];
        if (item.value.visibleIndex === index) {
          return item;
        }
      }
    }
  };

  View.prototype.onWillRemove = function(item) {};

  View.prototype.onDidInsert = function(baseItems) {
    return this.update();
  };


  /*
  00000000  000      00000000  00     00
  000       000      000       000   000
  0000000   000      0000000   000000000
  000       000      000       000 0 000
  00000000  0000000  00000000  000   000
   */

  View.prototype.getWidth = function(e) {
    return parseInt(window.getComputedStyle(e).width);
  };

  View.prototype.setWidth = function(e, w) {
    return e.style.width = w + "px";
  };

  View.prototype.getElem = function(clss, e) {
    if (e == null) {
      e = this.tree;
    }
    return e.getElementsByClassName(clss)[0];
  };


  /*
  00000000  000  000   000  0000000  
  000       000  0000  000  000   000
  000000    000  000 0 000  000   000
  000       000  000  0000  000   000
  000       000  000   000  0000000
   */

  View.prototype.findPath = function() {
    if (this.find.show()) {
      this.update();
    }
    return this.find.key.focus();
  };

  View.prototype.findValue = function() {
    if (this.find.show()) {
      this.update();
    }
    return this.find.val.focus();
  };

  View.prototype.refocus = function() {
    if (!document.activeElement.classList.contains('tree-item')) {
      log('focus selected');
      return setTimeout(this.focusSelected, 1);
    }
  };


  /*
  000   000  00000000  000   000  0000000     0000000   000   000  000   000
  000  000   000        000 000   000   000  000   000  000 0 000  0000  000
  0000000    0000000     00000    000   000  000   000  000000000  000 0 000
  000  000   000          000     000   000  000   000  000   000  000  0000
  000   000  00000000     000     0000000     0000000   00     00  000   000
   */

  View.prototype.onKeyDown = function(event) {
    var delta, first, keycode, last, n, ref;
    keycode = keyname.keycode(event);
    switch (keycode) {
      case 'left':
      case 'right':
        if (event.metaKey && event.altKey) {
          if (keycode === 'left') {
            this.base.collapseTop(true);
          } else {
            this.base.expandTop(true);
          }
        } else {
          if ((ref = this.selectedItem()) != null) {
            ref["select" + (_.capitalize(keycode))](event);
          }
        }
        return event.preventDefault();
      case 'home':
        return this.selectDelta(-this.numVisibleLines());
      case 'end':
        return this.selectDelta(this.numVisibleLines());
      case 'up':
        return this.selectUp(event);
      case 'down':
        return this.selectDown(event);
      case 'page up':
      case 'page down':
        n = event.shiftKey && this.numVisibleLines() || this.numViewLines();
        delta = keycode === 'page up' && -n || n;
        log('delta', delta);
        this.selectDelta(delta);
        first = _.first(this.root.children);
        last = _.last(this.root.children);
        if (last.value.visibleIndex === this.numVisibleLines() - 1) {
          return last.select();
        } else {
          return first.select();
        }
        break;
      default:
        return log(keycode);
    }
  };

  return View;

})(Proxy);

module.exports = View;

//# sourceMappingURL=view.js.map

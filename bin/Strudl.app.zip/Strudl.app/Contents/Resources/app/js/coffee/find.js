
/*
00000000  000  000   000  0000000  
000       000  0000  000  000   000
000000    000  000 0 000  000   000
000       000  000  0000  000   000
000       000  000   000  0000000
 */
var Emitter, Find, log, now,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

now = require('performance-now');

log = require('./tools/log');

Emitter = require('events');

Find = (function(superClass) {
  extend(Find, superClass);

  function Find(tree, elem) {
    this.tree = tree;
    this.elem = elem;
    this.applyFilter = bind(this.applyFilter, this);
    this.onBlur = bind(this.onBlur, this);
    this.onBlurTimer = bind(this.onBlurTimer, this);
    this.onFocus = bind(this.onFocus, this);
    this.onInput = bind(this.onInput, this);
    this.onKeyDown = bind(this.onKeyDown, this);
    this.key = this.getElem('input-key');
    this.val = this.getElem('input-val');
    this.key.on('input', this.onInput);
    this.val.on('input', this.onInput);
    this.key.on('blur', this.onBlur);
    this.val.on('blur', this.onBlur);
    this.key.on('focus', this.onFocus);
    this.val.on('focus', this.onFocus);
    this.key.on('keydown', this.onKeyDown);
    this.val.on('keydown', this.onKeyDown);
    this.filterTime = 50;
  }

  Find.prototype.onKeyDown = function(event) {
    var keycode;
    keycode = keyname.keycode(event);
    switch (keycode) {
      case 'esc':
        return this.clear();
      case 'enter':
        return this.applyFilter();
      case 'down':
        return this.emit('blur');
    }
  };

  Find.prototype.show = function() {
    if (this.elem.style.display === 'none') {
      this.elem.style.display = 'block';
      return true;
    }
  };

  Find.prototype.hide = function() {
    if (this.elem.style.display === 'block') {
      this.elem.style.display = 'none';
      this.emit('hidden');
      return true;
    }
  };

  Find.prototype.clear = function() {
    this.val.value = '';
    this.key.value = '';
    this.applyFilter();
    return this.hide();
  };

  Find.prototype.onInput = function(event) {
    if (this.timer != null) {
      clearTimeout(this.timer);
    }
    return this.timer = setTimeout(this.applyFilter, Math.min(1000, this.filterTime * 2));
  };

  Find.prototype.onFocus = function(event) {
    if (this.blurTimer != null) {
      clearTimeout(this.blurTimer);
      return this.blurTimer = null;
    }
  };

  Find.prototype.onBlurTimer = function(event) {
    this.blurTimer = null;
    return this.emit('blur');
  };

  Find.prototype.onBlur = function(event) {
    var ref;
    if ((ref = document.activeElement) !== this.key && ref !== this.val) {
      return this.blurTimer = setTimeout(this.onBlurTimer, 10);
    }
  };

  Find.prototype.applyFilter = function() {
    var key, start, val;
    this.timer = null;
    key = this.key.value;
    val = this.val.value;
    start = now();
    this.tree.data().setFilter(key, val);
    return this.filterTime = parseInt(now() - start);
  };


  /*
  00000000  000      00000000  00     00
  000       000      000       000   000
  0000000   000      0000000   000000000
  000       000      000       000 0 000
  00000000  0000000  00000000  000   000
   */

  Find.prototype.getElem = function(clss, e) {
    if (e == null) {
      e = this.elem;
    }
    return e.getElementsByClassName(clss)[0];
  };

  return Find;

})(Emitter);

module.exports = Find;

//# sourceMappingURL=find.js.map

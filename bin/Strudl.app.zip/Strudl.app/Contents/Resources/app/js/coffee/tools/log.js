
/*
000       0000000    0000000 
000      000   000  000      
000      000   000  000  0000
000      000   000  000   000
0000000   0000000    0000000
 */
var fs, str;

str = require('./str');

fs = require('fs');

module.exports = function() {
  var a, error, msg, stream;
  msg = ((function() {
    var i, len, results;
    results = [];
    for (i = 0, len = arguments.length; i < len; i++) {
      a = arguments[i];
      results.push(str(a));
    }
    return results;
  }).apply(this, arguments)).join(' ');
  console.log(msg);
  try {
    stream = fs.createWriteStream('/Users/kodi/Projects/strudl/strudl.log', {
      flags: 'a+',
      encoding: 'utf8'
    });
    stream.write(msg + "\n");
    return stream.end();
  } catch (error) {
    return console.log(msg);
  }
};

//# sourceMappingURL=log.js.map

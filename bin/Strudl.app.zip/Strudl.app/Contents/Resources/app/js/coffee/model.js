
/*
00     00   0000000   0000000    00000000  000    
000   000  000   000  000   000  000       000    
000000000  000   000  000   000  0000000   000    
000 0 000  000   000  000   000  000       000    
000   000   0000000   0000000    00000000  0000000
 */
var Emitter, Item, Model, log,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Emitter = require('events');

Item = require('./item');

log = require('./tools/log');

Model = (function(superClass) {
  extend(Model, superClass);

  function Model(name) {
    this.name = name != null ? name : 'model';
    this.lastID = -1;
  }

  Model.prototype.nextID = function() {
    return this.lastID += 1;
  };

  Model.prototype.inspect = function(depth) {
    return "[:" + this.name + ":]";
  };


  /*
  000  000000000  00000000  00     00
  000     000     000       000   000
  000     000     0000000   000000000
  000     000     000       000 0 000
  000     000     00000000  000   000
   */

  Model.prototype.getItem = function(keyPath) {
    return this.root.childAt(keyPath);
  };

  Model.prototype.itemAt = function(keyPath) {
    return this.root.childAt(keyPath);
  };


  /*
  00000000  0000000    000  000000000
  000       000   000  000     000   
  0000000   000   000  000     000   
  000       000   000  000     000   
  00000000  0000000    000     000
   */

  Model.prototype.setValue = function(item, value) {
    var oldValue;
    if (item.type === Item.valueType) {
      oldValue = item.value;
      item.value = value;
      return this.emit('didChange', item, oldValue);
    }
  };

  Model.prototype.remove = function(item) {
    log('will remove');
    this.emit('willRemove', [item]);
    item.parent.delChild(item);
    return this.root.updateDescendants();
  };

  Model.prototype.insert = function(parent, key, value) {
    this.root.updateDescendants();
    return this.emit('didInsert', [parent.childAt([key])]);
  };

  return Model;

})(Emitter);

module.exports = Model;

//# sourceMappingURL=model.js.map

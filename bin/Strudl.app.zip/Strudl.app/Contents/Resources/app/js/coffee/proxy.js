
/*
00000000   00000000    0000000   000   000  000   000
000   000  000   000  000   000   000 000    000 000 
00000000   0000000    000   000    00000      00000  
000        000   000  000   000   000 000      000   
000        000   000   0000000   000   000     000
 */
var ID, Item, Model, Proxy, ProxyItem, log, profile,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

log = require('./tools/log');

Model = require('./model');

profile = require('./tools/profile');

ProxyItem = require('./proxyitem');

Item = require('./item');

ID = 0;

Proxy = (function(superClass) {
  extend(Proxy, superClass);

  function Proxy(base, name) {
    var base1, ref;
    if (name == null) {
      name = 'proxy';
    }
    this.onDidChange = bind(this.onDidChange, this);
    this.onDidInsert = bind(this.onDidInsert, this);
    this.onWillRemove = bind(this.onWillRemove, this);
    this.onDidReload = bind(this.onDidReload, this);
    this.onWillReload = bind(this.onWillReload, this);
    Proxy.__super__.constructor.call(this, name + (ID += 1));
    this.itemMap = {};
    this.visibleItems = [];
    if (base instanceof Item) {
      this.baseItem = base;
      this.name += ':' + ((ref = this.baseItem) != null ? typeof ref.keyPath === "function" ? typeof (base1 = ref.keyPath()).join === "function" ? base1.join('.') : void 0 : void 0 : void 0);
      this.setBase(this.baseItem.model());
      this.root = this.createItem(-1, this.baseItem, this);
      this.expand(this.root);
    } else {
      if (base != null) {
        this.setBase(base);
      }
    }
  }

  Proxy.prototype.setBase = function(base1) {
    this.base = base1;
    this.base.on("willReload", this.onWillReload);
    this.base.on("didReload", this.onDidReload);
    this.base.on("willRemove", this.onWillRemove);
    this.base.on("didInsert", this.onDidInsert);
    return this.base.on("didChange", this.onDidChange);
  };

  Proxy.prototype.data = function() {
    var base1, ref;
    return (ref = typeof (base1 = this.base).data === "function" ? base1.data() : void 0) != null ? ref : this.base;
  };

  Proxy.prototype.onWillReload = function() {
    this.emit("willReload");
    return this.root = null;
  };

  Proxy.prototype.onDidReload = function() {
    var ref;
    if (this.base != null) {
      this.root = this.createItem(-1, (ref = this.baseItem) != null ? ref : this.base.root, this);
      this.emit("didReload");
      return this.expand(this.root);
    }
  };

  Proxy.prototype.newItem = function(key, value, parent) {
    return new ProxyItem(key, value, parent);
  };

  Proxy.prototype.createItem = function(key, value, parent) {
    var item;
    item = this.newItem(key, value, parent);
    item.id = this.nextID();
    if (item.isExpandable()) {
      item.unfetched = true;
    }
    this.itemMap[value.id] = item;
    return item;
  };

  Proxy.prototype.fetchItem = function(item) {
    var child, i, len, ref;
    if (item.unfetched) {
      if (item.isParent()) {
        ref = item.value.children;
        for (i = 0, len = ref.length; i < len; i++) {
          child = ref[i];
          item.addChild(this.createItem(child.key, child, item));
        }
      }
      return delete item.unfetched;
    }
  };

  Proxy.prototype.layout = function(item) {
    this.root.updateCounters();
    return this.emit('didLayout');
  };


  /*
  00000000  0000000    000  000000000
  000       000   000  000     000   
  0000000   000   000  000     000   
  000       000   000  000     000   
  00000000  0000000    000     000
   */

  Proxy.prototype.onWillRemove = function(baseItems) {
    var baseItem, i, item, len, results;
    results = [];
    for (i = 0, len = baseItems.length; i < len; i++) {
      baseItem = baseItems[i];
      item = this.itemMap[baseItem.id];
      if (item != null) {
        this.remove(item);
        results.push(this.layout());
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  Proxy.prototype.onDidInsert = function(baseItems) {
    var baseItem, i, index, item, len, parent, results;
    results = [];
    for (i = 0, len = baseItems.length; i < len; i++) {
      baseItem = baseItems[i];
      parent = this.itemMap[baseItem.parent.id];
      if ((parent != null) && (!parent.unfetched)) {
        index = baseItem.parent.children.indexOf(baseItem);
        item = this.createItem(baseItem.key, baseItem, parent);
        parent.insertChild(item, index);
        results.push(this.layout());
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  Proxy.prototype.onDidChange = function(baseItem, oldValue) {
    var item;
    item = this.itemMap[baseItem.id];
    if (item != null) {
      return this.emit("didChange", item, oldValue);
    }
  };


  /*
  00000000  000   000  00000000    0000000   000   000  0000000  
  000        000 000   000   000  000   000  0000  000  000   000
  0000000     00000    00000000   000000000  000 0 000  000   000
  000        000 000   000        000   000  000  0000  000   000
  00000000  000   000  000        000   000  000   000  0000000
   */

  Proxy.prototype.expand = function(item, recursive) {
    var child, i, len, ref;
    if (recursive == null) {
      recursive = false;
    }
    if (item.isExpandable()) {
      if (!item.expanded) {
        this.fetchItem(item);
        item.expanded = true;
      }
      if (recursive) {
        ref = item.children;
        for (i = 0, len = ref.length; i < len; i++) {
          child = ref[i];
          this.expand(child, recursive + 1);
        }
      }
      if (typeof recursive === 'boolean') {
        return this.layout(item);
      }
    }
  };

  Proxy.prototype.collapse = function(item, recursive) {
    var child, i, len, ref;
    if (recursive == null) {
      recursive = false;
    }
    if (item.isExpandable()) {
      if (recursive) {
        ref = item.children;
        for (i = 0, len = ref.length; i < len; i++) {
          child = ref[i];
          this.collapse(child, recursive + 1);
        }
      }
      if (item.expanded) {
        item.expanded = false;
      }
      if (typeof recursive === 'boolean') {
        return this.layout(item);
      }
    }
  };

  Proxy.prototype.expandItems = function(items, recursive) {
    var i, item, len;
    if (recursive == null) {
      recursive = false;
    }
    for (i = 0, len = items.length; i < len; i++) {
      item = items[i];
      this.expand(item, recursive && 1 || 0);
    }
    return this.layout(items[0]);
  };

  Proxy.prototype.collapseItems = function(items, recursive) {
    var i, item, len;
    if (recursive == null) {
      recursive = false;
    }
    for (i = 0, len = items.length; i < len; i++) {
      item = items[i];
      this.collapse(item, recursive && 1 || 0);
    }
    return this.layout(items[0]);
  };

  Proxy.prototype.expandTop = function(recursive) {
    if (recursive == null) {
      recursive = false;
    }
    return this.expandItems(this.root.children, recursive);
  };

  Proxy.prototype.collapseTop = function(recursive) {
    if (recursive == null) {
      recursive = false;
    }
    return this.collapseItems(this.root.children, recursive);
  };

  Proxy.prototype.collapseLeaves = function(recursive) {
    if (recursive == null) {
      recursive = false;
    }
    return this.collapseItems(this.leafItems(), recursive);
  };

  Proxy.prototype.expandLeaves = function() {
    return this.expandItems(this.leafItems());
  };


  /*
  000      00000000   0000000   00000000
  000      000       000   000  000     
  000      0000000   000000000  000000  
  000      000       000   000  000     
  0000000  00000000  000   000  000
   */

  Proxy.prototype.isLeaf = function(item) {
    if (item.isExpandable()) {
      return !item.expanded;
    } else {
      return true;
    }
  };

  Proxy.prototype.leafItems = function(item) {
    var child, i, leafs, len, ref;
    if (item == null) {
      item = this.root;
    }
    if (this.isLeaf(item)) {
      return [item];
    } else {
      leafs = [];
      ref = item.children;
      for (i = 0, len = ref.length; i < len; i++) {
        child = ref[i];
        leafs.push.apply(leafs, this.leafItems(child));
      }
      return leafs;
    }
  };

  return Proxy;

})(Model);

module.exports = Proxy;

//# sourceMappingURL=proxy.js.map

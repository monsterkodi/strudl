
/*
00000000   00000000    0000000   000   000  000   000  000  000000000  00000000  00     00
000   000  000   000  000   000   000 000    000 000   000     000     000       000   000
00000000   0000000    000   000    00000      00000    000     000     0000000   000000000
000        000   000  000   000   000 000      000     000     000     000       000 0 000
000        000   000   0000000   000   000     000     000     000     00000000  000   000
 */
var Item, ProxyItem, S, chalk, log,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

S = require('underscore.string');

chalk = require('chalk');

log = require('./tools/log');

Item = require('./item');

ProxyItem = (function(superClass) {
  extend(ProxyItem, superClass);

  function ProxyItem(key1, value1, prt) {
    this.key = key1;
    this.value = value1;
    this.numVisible = 0;
    if (this.key === -1) {
      this.mdl = prt;
      this.visibleIndex = -1;
    } else {
      this.parent = prt;
      this.visibleIndex = 0;
    }
    this.type = this.value.type;
    if (this.isParent()) {
      this.children = [];
    }
    if (this.isObject()) {
      this.keyIndex = {};
    }
    if (this.isExpandable()) {
      this.expanded = false;
    }
  }

  ProxyItem.prototype.setValue = function(value) {
    return this.value.setValue(value);
  };

  ProxyItem.prototype.getValue = function() {
    return this.value.getValue();
  };

  ProxyItem.prototype.remove = function() {
    return this.value.remove();
  };

  ProxyItem.prototype.insert = function(key, value) {
    return this.value.insert(key, value);
  };

  ProxyItem.prototype.depth = function() {
    return this.value.depth();
  };

  ProxyItem.prototype.dataItem = function() {
    var base, ref;
    return (ref = typeof (base = this.value).dataItem === "function" ? base.dataItem() : void 0) != null ? ref : this.value;
  };


  /*
  000   000  000   0000000  000  0000000    000      00000000
  000   000  000  000       000  000   000  000      000     
   000 000   000  0000000   000  0000000    000      0000000 
     000     000       000  000  000   000  000      000     
      0      000  0000000   000  0000000    0000000  00000000
   */

  ProxyItem.prototype.findFirstVisible = function(func, test) {
    var child, found, j, len, ref;
    if (test == null) {
      test = false;
    }
    if (test) {
      if (func(this)) {
        return this;
      }
    }
    if ((this.children != null) && this.expanded) {
      ref = this.children;
      for (j = 0, len = ref.length; j < len; j++) {
        child = ref[j];
        if (found = child.findFirstVisible(func, true)) {
          return found;
        }
      }
    }
    return null;
  };

  ProxyItem.prototype.updateCounters = function() {
    var incVis, vis;
    incVis = function(i) {
      i.numVisible += 1;
      if (i.parent != null) {
        return incVis(i.parent);
      }
    };
    this.numVisible = 0;
    this.mdl.visibleItems = [];
    vis = 0;
    return this.findFirstVisible((function(_this) {
      return function(i) {
        _this.mdl.visibleItems.push(i);
        i.numVisible = 0;
        incVis(i.parent);
        i.visibleIndex = vis;
        vis += 1;
        return false;
      };
    })(this));
  };


  /*
  00000000  000   000  00000000    0000000   000   000  0000000  
  000        000 000   000   000  000   000  0000  000  000   000
  0000000     00000    00000000   000000000  000 0 000  000   000
  000        000 000   000        000   000  000  0000  000   000
  00000000  000   000  000        000   000  000   000  0000000
   */

  ProxyItem.prototype.toggle = function() {
    if (this.isExpanded()) {
      return this.collapse();
    } else {
      return this.expand();
    }
  };

  ProxyItem.prototype.expand = function(recursive) {
    if (recursive == null) {
      recursive = false;
    }
    if (this.value instanceof ProxyItem) {
      return this.value.expand(recursive);
    } else {
      return this.model().expand(this, recursive);
    }
  };

  ProxyItem.prototype.collapse = function(recursive) {
    if (recursive == null) {
      recursive = false;
    }
    if (this.value instanceof ProxyItem) {
      return this.value.collapse(recursive);
    } else {
      return this.model().collapse(this, recursive);
    }
  };

  ProxyItem.prototype.isExpanded = function() {
    if (this.value instanceof ProxyItem) {
      return this.value.isExpanded();
    } else {
      return this.expanded;
    }
  };

  ProxyItem.prototype.isCollapsed = function() {
    return !this.isExpanded();
  };

  ProxyItem.prototype.isExpandable = function() {
    return this.isParent();
  };


  /*
  000  000   000   0000000  00000000   00000000   0000000  000000000
  000  0000  000  000       000   000  000       000          000   
  000  000 0 000  0000000   00000000   0000000   000          000   
  000  000  0000       000  000        000       000          000   
  000  000   000  0000000   000        00000000   0000000     000
   */

  ProxyItem.prototype.inspect = function(depth) {
    var c, id, indent, key, ref, s, v;
    indent = S.repeat(' ', 2);
    s = S.repeat(indent, depth - 2);
    if (this.value == null) {
      v = 'null';
    } else if (this.isExpandable()) {
      if (this.isCollapsed()) {
        v = '▶ ';
      } else {
        v = '▽ ';
        if (this.isArray()) {
          if (this.children.length) {
            c = this.children.map(function(i) {
              return i instanceof ProxyItem && i.inspect(depth + 1) || '';
            }).join(chalk.gray(',\n'));
            v += chalk.blue('[\n') + c + '\n' + s + indent + chalk.blue(' ]');
          } else {
            v += '[]';
          }
        } else if (this.isObject()) {
          if (this.children.length) {
            c = this.children.map(function(i) {
              return i instanceof ProxyItem && i.inspect(depth + 1) || '';
            }).join(chalk.gray(',\n'));
            v += chalk.magenta('{\n') + c + '\n' + s + indent + chalk.magenta(' }');
          } else {
            v += '{}';
          }
        }
      }
    } else {
      v = JSON.stringify(this.getValue());
    }
    id = "";
    key = ((ref = this.parent) != null ? ref.isArray() : void 0) && chalk.blue.bold(this.key) || ((this.parent != null) && chalk.yellow(this.key) || chalk.red.bold(this.model().name));
    return chalk.gray(s + " " + id + " " + key + ": ") + chalk.white.bold(v);
  };

  return ProxyItem;

})(Item);

module.exports = ProxyItem;

//# sourceMappingURL=proxyitem.js.map

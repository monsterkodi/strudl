
/*
00000000    0000000   000000000  000   000
000   000  000   000     000     000   000
00000000   000000000     000     000000000
000        000   000     000     000   000
000        000   000     000     000   000
 */
var Emitter, Path, _, log,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

_ = require('lodash');

log = require('./tools/log');

Emitter = require('events');

Path = (function(superClass) {
  extend(Path, superClass);

  function Path(elem) {
    this.elem = elem;
    this.onClick = bind(this.onClick, this);
    this.elem.addEventListener('click', this.onClick);
    this.elem.tabIndex = -1;
  }

  Path.prototype.onClick = function(event) {
    var idx;
    idx = event.target.idx;
    if (idx != null) {
      return this.emit('keypath', this.keys.slice(0, idx + 1));
    }
  };

  Path.prototype.set = function(keys1) {
    var arr, i, idx, key, keys, len, odd, oddOrEven, results, txt;
    this.keys = keys1;
    if (this.keys == null) {
      this.keys = [];
    }
    this.elem.innerHTML = "";
    if (this.keys.length) {
      keys = String(this.keys[0]).split('►');
      keys.push.apply(keys, this.keys.slice(1));
      odd = true;
      idx = 0;
      results = [];
      for (i = 0, len = keys.length; i < len; i++) {
        key = keys[i];
        oddOrEven = odd && 'odd' || 'even';
        txt = document.createElement('span');
        this.elem.appendChild(txt);
        txt.className = "pathText";
        txt.classList.add(oddOrEven);
        txt.innerHTML = key;
        txt.idx = idx;
        arr = document.createElement('span');
        this.elem.appendChild(arr);
        arr.className = "pathArrow";
        arr.classList.add(oddOrEven);
        if (idx === keys.length - 1) {
          arr.classList.add('last');
        }
        arr.idx = idx;
        odd = !odd;
        results.push(idx += 1);
      }
      return results;
    }
  };

  return Path;

})(Emitter);

module.exports = Path;

//# sourceMappingURL=path.js.map

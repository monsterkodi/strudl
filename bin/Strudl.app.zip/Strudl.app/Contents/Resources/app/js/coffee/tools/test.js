
/*
000000000  00000000   0000000  000000000
   000     000       000          000   
   000     0000000   0000000      000   
   000     000            000     000   
   000     00000000  0000000      000
 */
var Data, Proxy, chalk, data, dump, file, filePath, found, i, j, k, l, len, len1, len2, len3, log, profile, ref, ref1, ref2, ref3, v;

Proxy = require('../proxy');

Data = require('../data');

log = require('./log');

profile = require('./profile');

chalk = require('chalk');

data = new Data();

v = [];

v.push(new Proxy(data));

dump = function(msg) {
  var i, len, vw;
  profile("dump");
  log('-------------------------------- ' + msg);
  for (i = 0, len = v.length; i < len; i++) {
    vw = v[i];
    log('');
    console.log(vw.root);
  }
  return profile("");
};

if (true) {
  ref = ["test.json"];
  for (i = 0, len = ref.length; i < len; i++) {
    file = ref[i];
    filePath = "data/" + file;
    log("loading " + filePath + " ...");
    profile("load");
    data.load(filePath);
    profile('');
    console.log(data.root);
    v.push(new Proxy(data.itemAt('3')));
    v.push(new Proxy(data.itemAt('3')));
    v[0].expandLeaves();
    v[0].expandLeaves();
    v[1].expandLeaves();
    v[1].expandLeaves();
    v[1].root.collapse(true);
    data.itemAt('3.empty').insert(0, 666);
    data.itemAt('3.empty').insert(0, 999);
    data.itemAt('3.obj').insert('a', 0);
    data.itemAt('3.obj').insert('b', 1);
    data.itemAt('3.obj').insert('c', []);
    v[0].expandLeaves();
    v[0].expandLeaves();
    v[0].expandLeaves();
    data.itemAt('3.obj.c').insert('0', {
      'y': 2,
      'z': 3
    });
    v[0].expandLeaves();
    v[0].expandLeaves();
    data.itemAt('3.obj.c.0').insert('x', 1);
    v[0].expandLeaves();
    data.itemAt('3.empty.0').remove();
    data.itemAt('3.obj.b').remove();
    v[1].expandLeaves();
    v[1].expandLeaves();
    v[1].expandLeaves();
    v[1].expandLeaves();
    dump(filePath);
  }
}

if (true) {
  ref1 = ["test.json"];
  for (j = 0, len1 = ref1.length; j < len1; j++) {
    file = ref1[j];
    filePath = "data/" + file;
    log("loading " + filePath + " ...");
    profile("load");
    data.load(filePath);
    profile('');
    console.log(data.root);
    v.push(new Proxy(data.itemAt('5')));
    v.push(new Proxy(data.itemAt('5')));
    dump(filePath);
    v[0].expandLeaves();
    v[0].expandLeaves();
    v[0].collapse(v[0].itemAt('3'));
    v[0].collapse(v[0].itemAt('5'));
    dump('collapse 5');
    v[0].root.expand(true);
    v[0].root.collapse();
    v[0].root.collapse(true);
    v[1].root.collapse(true);
    v[1].root.expand(true);
    v[0].itemAt('5.0').setValue('bla');
    dump('remove');
  }
}

if (true) {
  ref2 = ["data.json"];
  for (k = 0, len2 = ref2.length; k < len2; k++) {
    file = ref2[k];
    filePath = "data/" + file;
    log("loading " + filePath + " ...");
    profile("load");
    data.load(filePath);
    profile("find *uid");
    found = data.findKey('*uid');
    log(found.length + " items");
    profile("find 666");
    found = data.findValue('*666*');
    log(found.length + " items");
    profile("find checksum 2286196866");
    found = data.findKeyValue('checksum', 2286196866);
    log(found.length + " items");
    profile("find key *");
    found = data.findKey('*');
    log(found.length + " items");
    profile('expand recursive');
    v[0].root.expand(true);
    profile('collapse recursive');
    v[0].root.collapse(true);
    v[0].root.expand();
    profile('');
  }
}

if (true) {
  ref3 = ["cards.json"];
  for (l = 0, len3 = ref3.length; l < len3; l++) {
    file = ref3[l];
    filePath = "data/" + file;
    log("loading " + filePath + " ...");
    profile("load");
    data.load(filePath);
    profile("find");
    found = data.findKeyValue('rarity', 'Mythic Rare');
    profile("find");
    found = data.findKey('rarity');
    log(found.length + " items");
    profile("find");
    found = data.findKeyValue('rarity', 'Rare');
    log(found.length + " items");
    profile("find");
    found = data.findValue('Forest');
    log(found.length + " items");
    profile('expand recursive');
    v[0].root.expand(true);
    profile('collapse recursive');
    v[0].root.collapse(true);
    v[0].root.expand();
    profile("");
  }
}

//# sourceMappingURL=test.js.map

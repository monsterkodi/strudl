
/*
00     00   0000000   000  000   000
000   000  000   000  000  0000  000
000000000  000000000  000  000 0 000
000 0 000  000   000  000  000  0000
000   000  000   000  000  000   000
 */
var DockMenu, Main, MainMenu, Window, _, app, dialog, fs, log, prefs,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

_ = require('lodash');

fs = require('fs');

app = require('app');

dialog = require('dialog');

Window = require('browser-window');

MainMenu = require('./mainmenu');

DockMenu = require('./dockmenu');

log = require('./tools/log');

prefs = require('./tools/prefs');

Main = (function() {
  Main.app = null;

  Main.init = function() {
    return Main.app = new Main();
  };

  function Main() {
    this.onReady = bind(this.onReady, this);
    this.wins = {};
    app.on('ready', this.onReady);
    app.on('open-file', function(e, p) {
      return prefs.one('open', p);
    });
    app.on('before-quit', function() {
      return Main.app.beforeQuit();
    });
    app.on('will-quit', function() {
      return log('on will-quit');
    });
    app.on('quit', function() {
      return log('on quit');
    });
    app.on('window-all-closed', function() {
      return log('on window-all-closed');
    });
    app.on('will-finish-launching', function() {});
  }

  Main.prototype.onReady = function() {
    log('app ready');
    app.removeAllListeners('open-file');
    app.on('open-file', (function(_this) {
      return function(e, p) {
        return _this.loadFile(p);
      };
    })(this));
    MainMenu.init(this);
    DockMenu.init(this);
    return this.loadPreferences();
  };


  /*
  00000000   00000000   00000000  00000000   0000000
  000   000  000   000  000       000       000     
  00000000   0000000    0000000   000000    0000000 
  000        000   000  000       000            000
  000        000   000  00000000  000       0000000
   */

  Main.prototype.loadPreferences = function() {
    var f, i, len, p, ref, results;
    app.clearRecentDocuments();
    p = prefs.load();
    ref = p.open;
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      f = ref[i];
      results.push(this.loadFile(f));
    }
    return results;
  };


  /*
  00000000  000  000      00000000
  000       000  000      000     
  000000    000  000      0000000 
  000       000  000      000     
  000       000  0000000  00000000
   */

  Main.prototype.loadFile = function(p) {
    var cwd, w, wd;
    if (this.wins[p] != null) {
      this.wins[p].focus();
      return;
    }
    cwd = __dirname;
    w = new Window({
      dir: cwd,
      preloadWindow: true,
      resizable: true,
      frame: true,
      show: true,
      center: false
    });
    wd = prefs.get('windows');
    if (wd[p] != null) {
      w.setBounds(wd[p]);
    }
    w.on('close', (function(_this) {
      return function(event) {
        var k;
        log('on window close');
        _this.saveBounds();
        k = _.findKey(_this.wins, event.sender);
        _this.wins[k].removeAllListeners();
        delete _this.wins[k];
        return prefs.del('open', p);
      };
    })(this));
    w.filePath = p;
    w.loadURL("file://" + cwd + "/../../win.html");
    this.wins[p] = w;
    prefs.one('open', p);
    return prefs.one('recent', p);
  };

  Main.prototype.openFile = function() {
    var f, i, len, p, results;
    p = dialog.showOpenDialog({
      properties: ['openFile'],
      filters: [
        {
          name: 'data',
          extensions: ['json', 'cson', 'plist']
        }
      ],
      properties: ['openFile', 'multiSelections']
    });
    if ((p != null ? p.length : void 0) != null) {
      results = [];
      for (i = 0, len = p.length; i < len; i++) {
        f = p[i];
        if (fs.existsSync(f)) {
          results.push(this.loadFile(f));
        } else {
          results.push(void 0);
        }
      }
      return results;
    }
  };


  /*
  0000000     0000000   000   000  000   000  0000000     0000000
  000   000  000   000  000   000  0000  000  000   000  000     
  0000000    000   000  000   000  000 0 000  000   000  0000000 
  000   000  000   000  000   000  000  0000  000   000       000
  0000000     0000000    0000000   000   000  0000000    0000000
   */

  Main.prototype.saveBounds = function() {
    var bounds, k, ref, w;
    bounds = prefs.get('windows');
    ref = this.wins;
    for (k in ref) {
      w = ref[k];
      bounds[k] = w.getBounds();
    }
    return prefs.set('windows', bounds);
  };


  /*
   0000000   000   000  000  000000000
  000   000  000   000  000     000   
  000 00 00  000   000  000     000   
  000 0000   000   000  000     000   
   00000 00   0000000   000     000
   */

  Main.prototype.beforeQuit = function() {
    var k, ref, results, w;
    app.clearRecentDocuments();
    this.saveBounds();
    ref = this.wins;
    results = [];
    for (k in ref) {
      w = ref[k];
      results.push(w.removeAllListeners('close'));
    }
    return results;
  };

  Main.prototype.quit = function() {
    app.clearRecentDocuments();
    return app.quit();
  };

  return Main;

})();

module.exports = Main;

//# sourceMappingURL=main.js.map

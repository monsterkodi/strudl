
/*
00     00   0000000   000  000   000  00     00  00000000  000   000  000   000
000   000  000   000  000  0000  000  000   000  000       0000  000  000   000
000000000  000000000  000  000 0 000  000000000  0000000   000 0 000  000   000
000 0 000  000   000  000  000  0000  000 0 000  000       000  0000  000   000
000   000  000   000  000  000   000  000   000  00000000  000   000   0000000
 */
var MainMenu, Menu, fs, log, prefs;

fs = require('fs');

Menu = require('menu');

prefs = require('./tools/prefs');

log = require('./tools/log');

MainMenu = (function() {
  function MainMenu() {}

  MainMenu.init = function(main) {
    var f, j, len, recent, ref;
    recent = [];
    ref = prefs.load().recent;
    for (j = 0, len = ref.length; j < len; j++) {
      f = ref[j];
      if (fs.existsSync(f)) {
        recent.push({
          label: f,
          click: function(i) {
            return main.loadFile(i.label);
          }
        });
      }
    }
    return Menu.setApplicationMenu(Menu.buildFromTemplate([
      {
        label: 'Strudel',
        submenu: [
          {
            label: 'About Strudl',
            role: 'about'
          }, {
            type: 'separator'
          }, {
            label: 'Hide Strudl',
            accelerator: 'Command+H',
            role: 'hide'
          }, {
            label: 'Hide Others',
            accelerator: 'Command+Alt+H',
            role: 'hideothers'
          }, {
            type: 'separator'
          }, {
            label: 'Quit',
            accelerator: 'Command+Q',
            click: function() {
              return main.quit();
            }
          }
        ]
      }, {

        /*
        00000000  000  000      00000000
        000       000  000      000     
        000000    000  000      0000000 
        000       000  000      000     
        000       000  0000000  00000000
         */
        label: 'File',
        role: 'file',
        submenu: [
          {
            label: 'Open...',
            accelerator: 'CmdOrCtrl+O',
            click: function() {
              return main.openFile();
            }
          }, {
            label: 'Open Recent',
            submenu: recent
          }, {
            type: 'separator'
          }, {
            label: 'Reload',
            accelerator: 'CmdOrCtrl+R',
            click: function(i, win) {
              return win != null ? win.reload() : void 0;
            }
          }
        ]
      }, {

        /*
        00000000  000  000   000  0000000  
        000       000  0000  000  000   000
        000000    000  000 0 000  000   000
        000       000  000  0000  000   000
        000       000  000   000  0000000
         */
        label: 'Find',
        submenu: [
          {
            label: 'Find Path',
            accelerator: 'CmdOrCtrl+F',
            click: function(i, win) {
              return win.emit('findPath');
            }
          }, {
            label: 'Find Value',
            accelerator: 'CmdOrCtrl+G',
            click: function(i, win) {
              return win.emit('findValue');
            }
          }, {
            label: 'Clear Find',
            accelerator: 'CmdOrCtrl+K',
            click: function(i, win) {
              return win.emit('clearFind');
            }
          }
        ]
      }, {
        label: 'View',
        role: 'view',
        submenu: [
          {
            label: 'Toggle FullScreen',
            accelerator: 'Ctrl+Command+F',
            click: function(i, win) {
              return win != null ? win.setFullScreen(!win.isFullScreen()) : void 0;
            }
          }
        ]
      }, {

        /*
        000   000  000  000   000  0000000     0000000   000   000
        000 0 000  000  0000  000  000   000  000   000  000 0 000
        000000000  000  000 0 000  000   000  000   000  000000000
        000   000  000  000  0000  000   000  000   000  000   000
        00     00  000  000   000  0000000     0000000   00     00
         */
        label: 'Window',
        role: 'window',
        submenu: [
          {
            label: 'Zoom',
            role: 'maximize'
          }, {
            label: 'Bring All to Front',
            role: 'front'
          }, {
            label: 'Minimize',
            accelerator: 'CmdOrCtrl+M',
            role: 'minimize'
          }
        ]
      }, {
        label: 'Help',
        role: 'help',
        submenu: []
      }
    ]));
  };

  return MainMenu;

})();

module.exports = MainMenu;

//# sourceMappingURL=mainmenu.js.map

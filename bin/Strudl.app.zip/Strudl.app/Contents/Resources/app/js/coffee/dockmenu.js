
/*
0000000     0000000    0000000  000   000  00     00  00000000  000   000  000   000
000   000  000   000  000       000  000   000   000  000       0000  000  000   000
000   000  000   000  000       0000000    000000000  0000000   000 0 000  000   000
000   000  000   000  000       000  000   000 0 000  000       000  0000  000   000
0000000     0000000    0000000  000   000  000   000  00000000  000   000   0000000
 */
var DockMenu, Menu, app, fs, prefs;

fs = require('fs');

app = require('app');

Menu = require('menu');

prefs = require('./tools/prefs');

DockMenu = (function() {
  function DockMenu() {}

  DockMenu.init = function(main) {
    var f, j, len, recent, ref;
    recent = [];
    ref = prefs.load().recent;
    for (j = 0, len = ref.length; j < len; j++) {
      f = ref[j];
      if (fs.existsSync(f)) {
        recent.push({
          label: f,
          click: function(i) {
            return main.loadFile(i.label);
          }
        });
      }
    }
    return app.dock.setMenu(Menu.buildFromTemplate([
      {
        label: 'Open Recent',
        submenu: recent
      }
    ]));
  };

  return DockMenu;

})();

module.exports = DockMenu;

//# sourceMappingURL=dockmenu.js.map


/*
00000000   00000000    0000000   00000000  000  000      00000000
000   000  000   000  000   000  000       000  000      000     
00000000   0000000    000   000  000000    000  000      0000000 
000        000   000  000   000  000       000  000      000     
000        000   000   0000000   000       000  0000000  00000000
 */
var log, now, profile, s_msg, start;

now = require('performance-now');

log = require('./log');

start = void 0;

s_msg = void 0;

profile = function(msg) {
  var ms;
  if ((start != null) && s_msg.length) {
    ms = (now() - start).toFixed(0);
    if (ms > 1000) {
      log(s_msg + " in " + ((ms / 1000).toFixed(3)) + " sec");
    } else {
      log(s_msg + " in " + ms + " ms");
    }
  }
  start = now();
  return s_msg = msg;
};

module.exports = profile;

//# sourceMappingURL=profile.js.map

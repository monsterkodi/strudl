
/*
0000000    00000000    0000000    0000000 
000   000  000   000  000   000  000      
000   000  0000000    000000000  000  0000
000   000  000   000  000   000  000   000
0000000    000   000  000   000   0000000
 */
var Drag, EventEmitter,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

EventEmitter = require('events');

Drag = (function(superClass) {
  extend(Drag, superClass);

  function Drag(elem) {
    this.elem = elem;
    this.onDragEnd = bind(this.onDragEnd, this);
    this.onDrag = bind(this.onDrag, this);
    this.onDragStart = bind(this.onDragStart, this);
    Drag.__super__.constructor.apply(this, arguments);
    this.elem.style.pointerEvents = 'all';
    this.elem.addEventListener('mousedown', this.onDragStart);
  }

  Drag.prototype.onDragStart = function(event) {
    if (event.target !== this.elem) {
      return;
    }
    window.addEventListener('mousemove', this.onDrag);
    window.addEventListener('mouseup', this.onDragEnd);
    this.x = event.clientX - this.elem.offsetWidth;
    this.y = event.clientY - this.elem.offsetHeight;
    this.sx = event.clientX;
    this.sy = event.clientY;
    return this.rx = this.ry = 0;
  };

  Drag.prototype.onDrag = function(event) {
    var ox, oy, ref, ref1, ref2;
    if (event.clientX || event.clientY) {
      this.x = event.clientX - this.elem.offsetWidth;
      this.y = event.clientY - this.elem.offsetHeight;
      ref = [this.rx, this.ry], ox = ref[0], oy = ref[1];
      ref1 = [event.clientX - this.sx, event.clientY - this.sy], this.rx = ref1[0], this.ry = ref1[1];
      ref2 = [ox - this.rx, oy - this.ry], this.dx = ref2[0], this.dy = ref2[1];
      return this.emit('drag', this);
    }
  };

  Drag.prototype.onDragEnd = function(event) {
    window.removeEventListener('mousemove', this.onDrag);
    return window.removeEventListener('mouseup', this.onDragEnd);
  };

  Drag.prototype.pos = function() {
    return this.elem.offsetLeft;
  };

  return Drag;

})(EventEmitter);

module.exports = Drag;

//# sourceMappingURL=drag.js.map

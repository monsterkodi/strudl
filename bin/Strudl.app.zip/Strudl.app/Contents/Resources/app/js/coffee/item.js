
/*
000  000000000  00000000  00     00
000     000     000       000   000
000     000     0000000   000000000
000     000     000       000 0 000
000     000     00000000  000   000
 */
var Item, S, _, chalk, log;

_ = require('lodash');

S = require('underscore.string');

chalk = require('chalk');

log = require('./tools/log');

Item = (function() {
  Item.valueType = 0;

  Item.arrayType = 1;

  Item.objectType = 2;

  function Item(key1, value1, prt) {
    this.key = key1;
    this.value = value1;
    this.numDescendants = 0;
    if (this.key === -1) {
      this.mdl = prt;
    } else {
      this.parent = prt;
    }
    if (this.value != null) {
      this.type = (function() {
        var ref;
        switch (this.value.constructor.name) {
          case 'Array':
            return Item.arrayType;
          case 'Object':
            return Item.objectType;
          default:
            return (ref = this.value.type) != null ? ref : Item.valueType;
        }
      }).call(this);
    } else {
      this.type = Item.valueType;
    }
    if (this.isParent()) {
      this.children = [];
    }
    if (this.isObject()) {
      this.keyIndex = {};
    }
  }

  Item.prototype.root = function() {
    var ref, ref1;
    return (ref = (ref1 = this.parent) != null ? ref1.root() : void 0) != null ? ref : this;
  };

  Item.prototype.model = function() {
    return this.root().mdl;
  };


  /*
  0000000    00000000  00000000   000000000  000   000
  000   000  000       000   000     000     000   000
  000   000  0000000   00000000      000     000000000
  000   000  000       000           000     000   000
  0000000    00000000  000           000     000   000
   */

  Item.prototype.isTop = function() {
    return this.parent === this.root();
  };

  Item.prototype.topItem = function() {
    var ref;
    return this.isTop() && this || ((ref = this.parent) != null ? ref.topItem() : void 0);
  };

  Item.prototype.depth = function() {
    return (this.parent != null) && (this.parent.depth() + 1) || 0;
  };


  /*
  00000000  0000000    000  000000000
  000       000   000  000     000   
  0000000   000   000  000     000   
  000       000   000  000     000   
  00000000  0000000    000     000
   */

  Item.prototype.getValue = function() {
    return this.value;
  };

  Item.prototype.setValue = function(value) {
    return this.model().setValue(this, value);
  };

  Item.prototype.remove = function() {
    return this.model().remove(this);
  };

  Item.prototype.insert = function(key, value) {
    return this.model().insert(this, key, value);
  };


  /*
  000000000  000   000  00000000   00000000
     000      000 000   000   000  000     
     000       00000    00000000   0000000 
     000        000     000        000     
     000        000     000        00000000
   */

  Item.prototype.typeName = function() {
    switch (this.type) {
      case 1:
        return 'Array';
      case 2:
        return 'Object';
      default:
        return 'Value';
    }
  };

  Item.prototype.isArray = function() {
    return this.type === Item.arrayType;
  };

  Item.prototype.isObject = function() {
    return this.type === Item.objectType;
  };


  /*
   0000000  000   000  000  000      0000000    00000000   00000000  000   000
  000       000   000  000  000      000   000  000   000  000       0000  000
  000       000000000  000  000      000   000  0000000    0000000   000 0 000
  000       000   000  000  000      000   000  000   000  000       000  0000
   0000000  000   000  000  0000000  0000000    000   000  00000000  000   000
   */

  Item.prototype.isParent = function() {
    return this.type !== Item.valueType;
  };

  Item.prototype.hasChildren = function() {
    return this.isParent() && (!_.isEmpty(this.children));
  };

  Item.prototype.addChild = function(child) {
    var index;
    index = (function() {
      switch (this.type) {
        case Item.objectType:
          this.keyIndex[child.key] = this.children.length;
          return this.children.length;
        case Item.arrayType:
          return parseInt(child.key);
      }
    }).call(this);
    return this.insertChild(child, index);
  };

  Item.prototype.insertChild = function(child, index) {
    var i, j, ref, ref1, results;
    if (index === this.children.length) {
      return this.children.push(child);
    } else {
      this.children.splice(index, 0, child);
      if (this.type === Item.arrayType) {
        results = [];
        for (i = j = ref = index + 1, ref1 = this.children.length; ref <= ref1 ? j < ref1 : j > ref1; i = ref <= ref1 ? ++j : --j) {
          results.push(this.children[i].key = i);
        }
        return results;
      }
    }
  };

  Item.prototype.delChild = function(child) {
    var index;
    if (this.type === Item.objectType) {
      index = this.keyIndex[child.key];
      this.children.splice(index, 1);
      return this.updateIndices();
    } else if (this.type === Item.arrayType) {
      index = this.children.indexOf(child);
      this.children.splice(index, 1);
      return this.updateIndices();
    }
  };

  Item.prototype.updateDescendants = function() {
    var child, j, len, ref;
    this.numDescendants = 1;
    if (this.isParent()) {
      ref = this.children;
      for (j = 0, len = ref.length; j < len; j++) {
        child = ref[j];
        this.numDescendants += child.updateDescendants();
      }
    }
    return this.numDescendants;
  };


  /*
  000  000   000  0000000    00000000  000   000
  000  0000  000  000   000  000        000 000 
  000  000 0 000  000   000  0000000     00000  
  000  000  0000  000   000  000        000 000 
  000  000   000  0000000    00000000  000   000
   */

  Item.prototype.indexInParent = function() {
    var ref, ref1, ref2;
    if (((ref = this.parent) != null ? (ref1 = ref.children) != null ? ref1.length : void 0 : void 0) < 1000) {
      return this.parent.children.indexOf(this);
    }
    switch ((ref2 = this.parent) != null ? ref2.type : void 0) {
      case Item.arrayType:
        return parseInt(this.key);
      case Item.objectType:
        return this.parent.keyIndex[this.key];
      default:
        return 0;
    }
  };

  Item.prototype.lastChild = function() {
    var ref;
    if ((ref = this.children) != null ? ref.length : void 0) {
      return this.children[this.children.length - 1].lastChild();
    }
    return this;
  };

  Item.prototype.updateIndices = function() {
    var index, j, k, ref, ref1, results, results1;
    if (this.type === Item.objectType) {
      this.keyIndex = {};
      results = [];
      for (index = j = 0, ref = this.children.length; 0 <= ref ? j < ref : j > ref; index = 0 <= ref ? ++j : --j) {
        results.push(this.keyIndex[this.children[index].key] = index);
      }
      return results;
    } else if (this.type === Item.arrayType) {
      results1 = [];
      for (index = k = 0, ref1 = this.children.length; 0 <= ref1 ? k < ref1 : k > ref1; index = 0 <= ref1 ? ++k : --k) {
        results1.push(this.children[index].key = index);
      }
      return results1;
    }
  };


  /*
  000   000  00000000  000   000  00000000    0000000   000000000  000   000
  000  000   000        000 000   000   000  000   000     000     000   000
  0000000    0000000     00000    00000000   000000000     000     000000000
  000  000   000          000     000        000   000     000     000   000
  000   000  00000000     000     000        000   000     000     000   000
   */

  Item.prototype.childAt = function(keyPath) {
    var index, key, ref, ref1, rest;
    if (_.isString(keyPath)) {
      keyPath = keyPath.split('.');
    }
    ref = [_.first(keyPath), _.rest(keyPath)], key = ref[0], rest = ref[1];
    if (this.type === Item.arrayType) {
      index = parseInt(key);
    } else {
      index = this.keyIndex[key];
    }
    if (rest.length) {
      return (ref1 = this.children[index]) != null ? ref1.childAt(rest) : void 0;
    } else {
      return this.children[index];
    }
  };

  Item.prototype.keyPath = function() {
    var pp, ref;
    if (((ref = this.parent) != null ? ref.keyPath : void 0) != null) {
      if (this.parent.parent != null) {
        pp = this.parent.keyPath();
        pp.push(this.key);
        return pp;
      } else {
        return [this.key];
      }
    } else {
      return [];
    }
  };


  /*
  000000000  00000000    0000000   000   000  00000000  00000000    0000000  00000000
     000     000   000  000   000  000   000  000       000   000  000       000     
     000     0000000    000000000   000 000   0000000   0000000    0000000   0000000 
     000     000   000  000   000     000     000       000   000       000  000     
     000     000   000  000   000      0      00000000  000   000  0000000   00000000
   */

  Item.prototype.eachAncestor = function(func) {
    var ref;
    func(this);
    return (ref = this.parent) != null ? ref.eachAncestor(func) : void 0;
  };

  Item.prototype.traverse = function(func, result, test) {
    var child, j, len, ref;
    if (result == null) {
      result = [];
    }
    if (test == null) {
      test = false;
    }
    if (test) {
      if (func(this)) {
        result.push(this);
      }
    }
    if (this.isParent()) {
      ref = this.children;
      for (j = 0, len = ref.length; j < len; j++) {
        child = ref[j];
        child.traverse(func, result, true);
      }
    }
    return result;
  };

  Item.prototype.findFirst = function(func, test) {
    var child, found, j, len, ref;
    if (test == null) {
      test = false;
    }
    if (test) {
      if (func(this)) {
        return this;
      }
    }
    if (this.children != null) {
      ref = this.children;
      for (j = 0, len = ref.length; j < len; j++) {
        child = ref[j];
        if (found = child.findFirst(func, true)) {
          return found;
        }
      }
    }
    return null;
  };


  /*
  000  000   000   0000000  00000000   00000000   0000000  000000000
  000  0000  000  000       000   000  000       000          000   
  000  000 0 000  0000000   00000000   0000000   000          000   
  000  000  0000       000  000        000       000          000   
  000  000   000  0000000   000        00000000   0000000     000
   */

  Item.prototype.inspect = function(depth) {
    var c, fetched, id, indent, key, ref, s, v;
    indent = S.repeat(' ', 2);
    s = S.repeat(indent, depth - 2);
    if (this.value == null) {
      v = 'null';
    } else if (this.value.inspect != null) {
      v = this.value.inspect(depth + 1);
    } else if (this.isParent()) {
      v = '';
      if (this.isArray()) {
        if (this.children.length) {
          c = this.children.map(function(i) {
            return (i.inspect != null) && i.inspect(depth + 1) || i;
          }).join(chalk.gray(',\n'));
          v += chalk.blue('[\n') + c + '\n' + s + indent + chalk.blue(' ]');
        } else {
          v += chalk.blue('[]');
        }
      } else if (this.isObject()) {
        if (this.children.length) {
          c = this.children.map(function(i) {
            return (i.inspect != null) && i.inspect(depth + 1) || i;
          }).join(chalk.gray(',\n'));
          v += chalk.magenta('{\n') + c + '\n' + s + indent + chalk.magenta(' }');
        } else {
          v += chalk.magenta('{}');
        }
      }
    } else {
      v = JSON.stringify(this.getValue());
    }
    id = "";
    key = ((ref = this.parent) != null ? ref.isArray() : void 0) && chalk.blue.bold(this.key) || ((this.parent != null) && chalk.yellow(this.key) || chalk.red.bold(this.model().name));
    fetched = this.unfetched && " unfetched" || "";
    return chalk.gray(s + " " + id + " " + key + ": ") + chalk.white.bold(v) + chalk.gray(fetched);
  };

  return Item;

})();

module.exports = Item;

//# sourceMappingURL=item.js.map

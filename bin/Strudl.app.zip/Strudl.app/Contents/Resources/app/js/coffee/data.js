
/*
0000000     0000000   000000000   0000000 
000   000  000   000     000     000   000
000   000  000000000     000     000000000
000   000  000   000     000     000   000
0000000    000   000     000     000   000
 */
var DataModel, Item, Model, _, fs, log, path, profile,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Model = require('./model');

Item = require('./item');

profile = require('./tools/profile');

log = require('./tools/log');

path = require('path');

fs = require('fs');

_ = require('lodash');

DataModel = (function(superClass) {
  extend(DataModel, superClass);

  function DataModel() {
    return DataModel.__super__.constructor.apply(this, arguments);
  }

  DataModel.prototype.load = function(filePath) {
    this.filePath = filePath;
    this.emit('willReload');
    if (path.extname(this.filePath) === '.plist') {
      this.data = require('simple-plist').readFileSync(this.filePath);
    } else {
      this.data = this.parseString(fs.readFileSync(this.filePath));
    }
    profile("create tree");
    this.root = this.createItem(-1, this.data, this);
    this.root.updateDescendants();
    this.dataRoot = this.root;
    profile("");
    log(this.lastID + " items");
    return this.emit('didReload');
  };

  DataModel.prototype.parseString = function(stringData) {
    switch (path.extname(this.filePath)) {
      case '.cson':
        return require('CSON').parse(stringData);
      default:
        return JSON.parse(stringData);
    }
  };

  DataModel.prototype.setFilter = function(path, value) {
    var f, i, j, len, ref;
    this.emit('willReload');
    if (path && value) {
      this.filtered = this.findPathValue(path, value);
    } else if (path) {
      this.filtered = this.findPath(path);
    } else if (value) {
      this.filtered = this.findValue(value);
    } else {
      this.filtered = null;
      this.root = this.dataRoot;
      this.emit('didReload');
      return;
    }
    f = {};
    ref = this.filtered;
    for (j = 0, len = ref.length; j < len; j++) {
      i = ref[j];
      f[i.keyPath().join('►')] = i.value;
    }
    this.root = this.createItem(-1, f, this);
    this.root.updateDescendants();
    return this.emit('didReload');
  };


  /*
  000  000000000  00000000  00     00
  000     000     000       000   000
  000     000     0000000   000000000
  000     000     000       000 0 000
  000     000     00000000  000   000
   */

  DataModel.prototype.createItem = function(key, data, parent) {
    var index, item, j, k, len, ref, ref1;
    item = new Item(key, data, parent);
    item.id = this.nextID();
    switch (item.type) {
      case Item.arrayType:
        for (index = j = 0, ref = data.length; 0 <= ref ? j < ref : j > ref; index = 0 <= ref ? ++j : --j) {
          item.addChild(this.createItem(index, data[index], item));
        }
        break;
      case Item.objectType:
        ref1 = Object.keys(data);
        for (k = 0, len = ref1.length; k < len; k++) {
          key = ref1[k];
          item.addChild(this.createItem(key, data[key], item));
        }
    }
    return item;
  };


  /*
  00000000  0000000    000  000000000
  000       000   000  000     000   
  0000000   000   000  000     000   
  000       000   000  000     000   
  00000000  0000000    000     000
   */

  DataModel.prototype.insert = function(parent, key, value) {
    parent.addChild(this.createItem(key, value, parent));
    return DataModel.__super__.insert.apply(this, arguments);
  };

  DataModel.prototype.setValue = function(item, value) {
    item.parent.value[item.key] = value;
    return DataModel.__super__.setValue.apply(this, arguments);
  };


  /*
  00000000  000  000   000  0000000  
  000       000  0000  000  000   000
  000000    000  000 0 000  000   000
  000       000  000  0000  000   000
  000       000  000   000  0000000
   */

  DataModel.prototype.reg = function(s) {
    s = s.replace(/([^.]+\|[^.]+)/g, '($1)');
    s = s.replace(/\./g, '\\.');
    s = s.replace(/\*\*/g, '^^');
    s = s.replace(/\*/g, '[^.]*');
    s = s.replace(/\^\^/g, '.*');
    return new RegExp("^" + s + "$");
  };

  DataModel.prototype.findKeyValue = function(key, val, item) {
    var keyReg, valReg;
    if (item == null) {
      item = this.dataRoot;
    }
    keyReg = this.reg(key);
    valReg = this.reg(val);
    return item.traverse((function(_this) {
      return function(i) {
        return _this.match(i.key, keyReg) && _this.match(i.getValue(), valReg);
      };
    })(this));
  };

  DataModel.prototype.findValue = function(val, item) {
    var valReg;
    if (item == null) {
      item = this.dataRoot;
    }
    valReg = this.reg(val);
    return item.traverse((function(_this) {
      return function(i) {
        return _this.match(i.getValue(), valReg);
      };
    })(this));
  };

  DataModel.prototype.findKey = function(key, item) {
    var keyReg;
    if (item == null) {
      item = this.dataRoot;
    }
    keyReg = this.reg(key);
    return item.traverse((function(_this) {
      return function(i) {
        return _this.match(i.key, keyReg);
      };
    })(this));
  };

  DataModel.prototype.findPath = function(path, item) {
    var pthReg;
    if (item == null) {
      item = this.dataRoot;
    }
    pthReg = this.reg(path);
    return item.traverse((function(_this) {
      return function(i) {
        return _this.matchPath(i.keyPath(), pthReg);
      };
    })(this));
  };

  DataModel.prototype.findPathValue = function(path, val, item) {
    var pthReg, valReg;
    if (item == null) {
      item = this.dataRoot;
    }
    pthReg = this.reg(path);
    valReg = this.reg(val);
    return item.traverse((function(_this) {
      return function(i) {
        return _this.matchPath(i.keyPath(), pthReg) && _this.match(i.getValue(), valReg);
      };
    })(this));
  };

  DataModel.prototype.matchPath = function(a, r) {
    return this.match(a.join('.'), r);
  };

  DataModel.prototype.match = function(a, r) {
    var ref, sa;
    if (!_.isArray(a)) {
      sa = String(a);
      return (ref = sa.match(r)) != null ? ref.length : void 0;
    } else {
      return false;
    }
  };

  return DataModel;

})(Model);

module.exports = DataModel;

//# sourceMappingURL=data.js.map

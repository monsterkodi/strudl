
/*
000   000  000  00000000  000   000  000  000000000  00000000  00     00
000   000  000  000       000 0 000  000     000     000       000   000
 000 000   000  0000000   000000000  000     000     0000000   000000000
   000     000  000       000   000  000     000     000       000 0 000
    0      000  00000000  00     00  000     000     00000000  000   000
 */
var Drag, Item, Path, ProxyItem, ViewItem, _, log,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

_ = require('lodash');

log = require('./tools/log');

Item = require('./item');

Drag = require('./drag');

Path = require('./path');

ProxyItem = require('./proxyitem');

ViewItem = (function(superClass) {
  extend(ViewItem, superClass);

  function ViewItem(key1, value, prt) {
    this.key = key1;
    this.value = value;
    this.hasFocus = bind(this.hasFocus, this);
    this.onFocus = bind(this.onFocus, this);
    this.onBlur = bind(this.onBlur, this);
    this.onWheel = bind(this.onWheel, this);
    this.onValDrag = bind(this.onValDrag, this);
    this.onKeyPath = bind(this.onKeyPath, this);
    this.onClick = bind(this.onClick, this);
    ViewItem.__super__.constructor.apply(this, arguments);
  }


  /*
  00000000  000      00000000  00     00
  000       000      000       000   000
  0000000   000      0000000   000000000
  000       000      000       000 0 000
  00000000  0000000  00000000  000   000
   */

  ViewItem.prototype.createElement = function() {
    var chd, dsc, key, spc, val, vis;
    if (this.key !== -1) {
      this.idx = document.createElement('div');
      this.idx.className = "tree-item idx";
      this.idx.innerHTML = this.value.visibleIndex + " ";
      this.idx.id = "" + (this.indexInParent());
      this.lin = document.createElement('span');
      this.lin.className = 'tree-line';
      this.lin.addEventListener('click', this.onClick);
      this.lin.tabIndex = -1;
      this.idx.appendChild(this.lin);
      this.elm = document.createElement('div');
      this.elm.className = "tree-item key";
      this.elm.tabIndex = -1;
      new Drag(this.elm).on('drag', this.model().onDrag);
      spc = document.createElement('span');
      spc.addEventListener('click', (function(_this) {
        return function(event) {
          return _this.onClick(event, true);
        };
      })(this));
      spc.className = "tree-value spc";
      spc.style.minWidth = (this.depth() * 30) + ".px";
      spc.innerHTML = "&nbsp;";
      new Drag(spc).on('drag', this.model().onDrag);
      if (this.isExpandable()) {
        spc.classList.add(this.isExpanded() && "expanded" || "collapsed");
      }
      this.elm.appendChild(spc);
      this.elm.addEventListener('click', this.onClick);
      this.elm.addEventListener('blur', this.onBlur);
      this.elm.addEventListener('focus', this.onFocus);
      this.split = String(this.key).split('►');
      key = document.createElement('span');
      key.addEventListener('click', this.onClick);
      key.className = "tree-value key " + this.typeName().toLowerCase();
      if (this.split.length === 1) {
        key.innerHTML = this.key;
        if (this.parent.type === Item.arrayType) {
          this.addClass('array-index', key);
        }
      } else {
        this.pth = new Path(key);
        this.pth.set(this.split);
        this.pth.on('keypath', this.onKeyPath);
      }
      this.elm.appendChild(key);
      this.val = document.createElement('div');
      this.val.className = "tree-item val " + this.typeName().toLowerCase();
      this.val.addEventListener('wheel', this.onWheel);
      this.val.addEventListener('click', this.onClick);
      this.valDrag = new Drag(this.val);
      this.valDrag.on('drag', this.onValDrag);
      val = document.createElement('span');
      val.className = "tree-value val";
      this.val.appendChild(val);
      this.num = document.createElement('div');
      this.num.className = "tree-item num";
      if (this.isParent()) {
        dsc = document.createElement('span');
        dsc.className = "tree-value dsc";
        chd = document.createElement('span');
        chd.className = "tree-value chd";
        vis = document.createElement('span');
        vis.className = "tree-value vis";
        this.num.appendChild(dsc);
        this.num.appendChild(chd);
        this.num.appendChild(vis);
      }
      this.col('idx').appendChild(this.idx);
      this.col('key').appendChild(this.elm);
      this.col('val').appendChild(this.val);
      this.col('num').appendChild(this.num);
      return this.update();
    }
  };

  ViewItem.prototype.col = function(name) {
    return this.getElem(name, this.root().elem);
  };


  /*
  000   000  00000000   0000000     0000000   000000000  00000000
  000   000  000   000  000   000  000   000     000     000     
  000   000  00000000   000   000  000000000     000     0000000 
  000   000  000        000   000  000   000     000     000     
   0000000   000        0000000    000   000     000     00000000
   */

  ViewItem.prototype.update = function() {
    var chd, dsc, ref, vis;
    if (this.isParent()) {
      vis = this.getElem('vis', this.num);
      chd = this.getElem('chd', this.num);
      dsc = this.getElem('dsc', this.num);
      vis.innerHTML = this.isExpanded() && ("" + this.value.numVisible) || "";
      chd.innerHTML = "" + (this.dataItem().children.length);
      dsc.innerHTML = "" + (this.dataItem().numDescendants - 1);
    }
    switch (this.type) {
      case Item.objectType:
        return this.val.firstElementChild.innerHTML = this.getValue()['name'] || '';
      case Item.valueType:
        return this.val.firstElementChild.innerHTML = (ref = this.getValue()) != null ? ref : 'null';
    }
  };

  ViewItem.prototype.removeElement = function() {
    this.elm.remove();
    this.idx.remove();
    this.val.remove();
    return this.num.remove();
  };

  ViewItem.prototype.delChild = function(child) {
    child.removeElement();
    return ViewItem.__super__.delChild.apply(this, arguments);
  };

  ViewItem.prototype.nextItem = function() {
    return this.parent.children[this.indexInParent() + 1];
  };

  ViewItem.prototype.prevItem = function() {
    return this.parent.children[this.indexInParent() - 1];
  };


  /*
   0000000  000      000   0000000  000   000
  000       000      000  000       000  000 
  000       000      000  000       0000000  
  000       000      000  000       000  000 
   0000000  0000000  000   0000000  000   000
   */

  ViewItem.prototype.onClick = function(event, toggle) {
    if (toggle == null) {
      toggle = false;
    }
    if (this.hasClass('selected', this.lin)) {
      toggle = true;
    }
    this.focus();
    if (toggle) {
      this.toggle();
    }
    this.select(event);
    return event.stopPropagation();
  };

  ViewItem.prototype.onKeyPath = function(keypath) {
    return this.model().data().setFilter(keypath.join('.'));
  };


  /*
   0000000   0000000  00000000    0000000   000      000    
  000       000       000   000  000   000  000      000    
  0000000   000       0000000    000   000  000      000    
       000  000       000   000  000   000  000      000    
  0000000    0000000  000   000   0000000   0000000  0000000
   */

  ViewItem.prototype.onValDrag = function(drag) {
    if (this.scrollable()) {
      return this.scrollBy(drag.dx);
    }
  };

  ViewItem.prototype.onWheel = function(event) {
    if (this.scrollable() && Math.abs(event.deltaX) > Math.abs(event.deltaY)) {
      this.scrollBy(event.deltaX);
      return event.stopPropagation();
    }
  };

  ViewItem.prototype.scrollable = function() {
    return this.val.clientWidth < this.val.firstElementChild.clientWidth;
  };

  ViewItem.prototype.scrollBy = function(delta) {
    var left, v;
    v = this.val.firstElementChild;
    left = this.getLeft(v) - delta;
    left = Math.min(0, left);
    left = Math.max(left, -v.offsetWidth);
    return this.setLeft(v, left);
  };


  /*
   0000000  00000000  000      00000000   0000000  000000000
  000       000       000      000       000          000   
  0000000   0000000   000      0000000   000          000   
       000  000       000      000       000          000   
  0000000   00000000  0000000  00000000   0000000     000
   */

  ViewItem.prototype.deselect = function() {
    this.delClass('selected', this.lin);
    this.delClass('focus', this.lin);
    this.elm.tabIndex = -1;
    return this.root().elem.focus();
  };

  ViewItem.prototype.select = function() {
    log('viewitem.select', this.value.visibleIndex);
    return this.model().selectIndex(this.value.visibleIndex);
  };

  ViewItem.prototype.onBlur = function() {
    return this.clrClass('focus');
  };

  ViewItem.prototype.onFocus = function() {
    return this.ownClass('focus', this.lin);
  };

  ViewItem.prototype.hasFocus = function() {
    return document.activeElement === this.elm;
  };

  ViewItem.prototype.focus = function(event) {
    this.ownClass('selected', this.lin);
    this.ownClass('focus', this.lin);
    if (this.elm !== document.activeElement) {
      this.elm.focus();
      return this.elm.tabIndex = 2;
    }
  };

  ViewItem.prototype.selectLeft = function(event) {
    if (event.metaKey) {
      return this.collapse(true);
    } else if (event.altKey) {
      if (!this.isTop()) {
        return this.parent.select();
      }
    } else if (this.isExpanded()) {
      return this.collapse();
    } else {
      return this.model().selectUp(event);
    }
  };

  ViewItem.prototype.selectRight = function(event) {
    if (event.metaKey) {
      return this.expand(true);
    } else if (this.isExpandable() && !this.isExpanded()) {
      return this.expand(false);
    } else {
      return this.model().selectDown(event);
    }
  };


  /*
   0000000  000       0000000   0000000
  000       000      000       000     
  000       000      0000000   0000000 
  000       000           000       000
   0000000  0000000  0000000   0000000
   */

  ViewItem.prototype.getLeft = function(e) {
    return parseInt(window.getComputedStyle(e).left);
  };

  ViewItem.prototype.setLeft = function(e, w) {
    return e.style.left = w + "px";
  };

  ViewItem.prototype.getElem = function(clss, e) {
    if (e == null) {
      e = this.elm;
    }
    return e.getElementsByClassName(clss)[0];
  };

  ViewItem.prototype.hasClass = function(clss, e) {
    if (e == null) {
      e = this.elm;
    }
    return e.classList.contains(clss);
  };

  ViewItem.prototype.delClass = function(clss, e) {
    if (e == null) {
      e = this.elm;
    }
    return e.classList.remove(clss);
  };

  ViewItem.prototype.addClass = function(clss, e) {
    if (e == null) {
      e = this.elm;
    }
    return e.classList.add(clss);
  };

  ViewItem.prototype.toggleClass = function(clss, e) {
    if (e == null) {
      e = this.elm;
    }
    if (e.classList.contains(clss)) {
      return e.classList.remove(clss);
    } else {
      return e.classList.add(clss);
    }
  };

  ViewItem.prototype.swapClass = function(delClss, addClss, e) {
    if (e == null) {
      e = this.elm;
    }
    this.delClass(delClss, e);
    return this.addClass(addClss, e);
  };

  ViewItem.prototype.clrClass = function(clss) {
    var results;
    results = [];
    while (document.getElementsByClassName(clss).length) {
      results.push(document.getElementsByClassName(clss)[0].classList.remove(clss));
    }
    return results;
  };

  ViewItem.prototype.ownClass = function(clss, e) {
    if (e == null) {
      e = this.elm;
    }
    this.clrClass(clss);
    return e != null ? e.classList.add(clss) : void 0;
  };

  return ViewItem;

})(ProxyItem);

module.exports = ViewItem;

//# sourceMappingURL=viewitem.js.map
